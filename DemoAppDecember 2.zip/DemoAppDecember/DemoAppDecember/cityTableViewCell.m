//
//  cityTableViewCell.m
//  DemoAppDecember
//
//  Created by RanbijaySinghDeo on 24/12/15.
//  Copyright © 2015 RanbijaySinghDeo. All rights reserved.
//

#import "cityTableViewCell.h"

@implementation cityTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
