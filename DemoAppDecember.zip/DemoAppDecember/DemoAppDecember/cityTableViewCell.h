//
//  cityTableViewCell.h
//  DemoAppDecember
//
//  Created by RanbijaySinghDeo on 24/12/15.
//  Copyright © 2015 RanbijaySinghDeo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface cityTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *CityNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *CountryNameLabel;

@end
